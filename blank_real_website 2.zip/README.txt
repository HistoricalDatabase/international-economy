BLANK REAL WEBSITE
===================

Files:
- index.html
- style.css
- script.js

This is a real responsive website, not a slideshow. Open index.html in a browser to preview it.

IMPORTANT:
A static HTML site cannot provide shared cloud editing by itself. To have a public URL and invite other people to edit the site's files, publish this folder through a web host/repository that supports collaboration (for example GitHub Pages with a GitHub repository). The website code itself is ready.
